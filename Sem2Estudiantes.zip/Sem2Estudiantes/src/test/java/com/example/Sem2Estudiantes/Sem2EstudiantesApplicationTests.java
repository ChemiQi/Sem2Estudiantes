package com.example.Sem2Estudiantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sem2EstudiantesApplicationTests {

	@Test
	void contextLoads() {
	}

}
