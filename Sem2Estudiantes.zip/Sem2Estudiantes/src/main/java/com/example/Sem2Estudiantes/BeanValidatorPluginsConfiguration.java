package com.example.Sem2Estudiantes;

public class BeanValidatorPluginsConfiguration {
}
