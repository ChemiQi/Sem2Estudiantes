package com.example.Sem2Estudiantes.domain;

public enum branch {
    Back,
    Front,
    devops,
    unasignaded;
}
